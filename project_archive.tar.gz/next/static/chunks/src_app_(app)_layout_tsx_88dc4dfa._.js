(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_d1340a16._.js",
  "static/chunks/node_modules_efc30b15._.js"
],
    source: "dynamic"
});
