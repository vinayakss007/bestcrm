(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_59acd4d9._.js",
  "static/chunks/src_09b94a72._.js"
],
    source: "dynamic"
});
