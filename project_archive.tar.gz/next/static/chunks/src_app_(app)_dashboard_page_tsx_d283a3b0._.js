(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_lodash_94bba183._.js",
  "static/chunks/node_modules_recharts_es6_7fc8f95a._.js",
  "static/chunks/node_modules_b861a56b._.js",
  "static/chunks/src_39f690a9._.js"
],
    source: "dynamic"
});
