(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_lodash_94bba183._.js",
  "static/chunks/node_modules_recharts_es6_7fc8f95a._.js",
  "static/chunks/node_modules_92782886._.js",
  "static/chunks/src_7fcd9561._.js"
],
    source: "dynamic"
});
