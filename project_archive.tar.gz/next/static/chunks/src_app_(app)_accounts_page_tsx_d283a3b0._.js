(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_34f207bf._.js",
  "static/chunks/src_components_29b3cea2._.js"
],
    source: "dynamic"
});
