(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_d5791a77._.js",
  "static/chunks/src_components_ui_90f615aa._.js"
],
    source: "dynamic"
});
